//
// Created by seanblanchard on 9/24/20.
//

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define OH "O"
#define CROSS "X"

void *runner(void *param); // the thread

int main(int argc, char *argv[])
{
    srand(clock()); // randomize rand() with system clock

    pthread_t tid1, tid2; // the thread identifier

    // create the thread
    pthread_create(&tid1, NULL, runner, (void *) OH);
    pthread_create(&tid2, NULL, runner, (void *) CROSS);

    // wait for the first thread to exit
    pthread_join(tid1, NULL);
    pthread_join(tid2, NULL);

    putc('\n', stdout);
}

void *runner(void *param)
{
    char ch = ((char *) param)[0];
    for (int i = 1; i <= 10; i++)
    {
        sleep(2*((float)rand())/RAND_MAX);
        putc(ch, stdout);
        fflush(stdout);
    }

    pthread_exit(0);
}
