#define _GNU_SOURCE // needed for Linux-specific scheduling policies

#include <pthread.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

#define RT_PRIORITY 99 // valid only for real-time policies (FIFO, RR) // SUDO !
#define NORMAL_PRIORITY 0 // must be 0 for "normal" policies (OTHER, IDLE, BATCH)

struct sched_param schedparam;

void print_thread_schedparam(char *who)
{
   int my_policy;
   struct sched_param my_param;

   printf( "Hello world from %s\n", who);

   pthread_getschedparam (pthread_self (), &my_policy, &my_param);
   printf ("ID#%ld running at %s/%d\n",
           pthread_self() ,
           ( my_policy == SCHED_FIFO ? "FIFO"
             : ( my_policy == SCHED_RR ? "RR"
                 : (my_policy == SCHED_OTHER ? "OTHER"
                    : (my_policy == SCHED_IDLE ? "IDLE"
                       : (my_policy == SCHED_BATCH ? "BATCH"
                          : "unknown") ) ) ) ),
           my_param.sched_priority);

   fflush(stdout);
}

void*runner(void *param)
{
   print_thread_schedparam("runner thread: checkpoint 1");
   // change policy in a running thread - NOTE: no bug here, so can use
   // SCHED_IDLE and SCHED_BATCH along the others
   schedparam.sched_priority = NORMAL_PRIORITY;
   pthread_setschedparam(pthread_self(), SCHED_IDLE, &schedparam);
   print_thread_schedparam("runner thread: checkpoint 2");
   pthread_exit(NULL);
}

int main(int argc, char*argv[])
{
   print_thread_schedparam("main thread");

   pthread_t tid;
   pthread_attr_t attr;

   // get the default attributes
   pthread_attr_init(&attr);

   // specialize attributes

   if (pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM) != 0)
      printf("Cannot set scope\n");
   if (pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED) != 0)
      printf("Cannot set inheritsched\n");
   // NOTE:
   // there is a Linux bug that prevents setting attributes to SCHED_IDLE
   // and SCHED_BATCH
   // https://sourceware.org/bugzilla/show_bug.cgi?id=7013
   if (pthread_attr_setschedpolicy(&attr, SCHED_RR) != 0)
      printf("Cannot set schedpolicy\n");
   schedparam.sched_priority = RT_PRIORITY;
   // schedparam.sched_priority = NORMAL_PRIORITY;
   if (pthread_attr_setschedparam(&attr, &schedparam) != 0)
      printf("Cannot set schedparam\n");
   if (pthread_create(&tid, &attr, &runner, &argv) != 0)
      printf("Cannot create thread\n");
   // getchar();
   pthread_join(tid, NULL);
   pthread_attr_destroy(&attr);
}
