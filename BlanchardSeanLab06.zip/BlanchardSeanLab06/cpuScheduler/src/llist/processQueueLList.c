/**
* Name: Sean Blanchard
* Lab/task: Lab 6
* Date: 10/4/20
**/
#include "processQueue.h"

// the process table to hold all processes
PROCESS *processTable;
int processTableSize = 0;
int processTableCapacity;

// doubly-linked list to hold the ready queue
PROCESS *readyQueueHead = NULL;
PROCESS *readyQueueTail = NULL;

/***
 * constructor of the process table
 */
void createProcessTable(int capacity)
{
    processTable = (PROCESS *) malloc(capacity * sizeof(PROCESS));
    processTableCapacity = capacity;
}

/***
 * constructor of the ready queue
 */
void createReadyQueue(int capacity)
{
    readyQueueHead = NULL;
    readyQueueTail = NULL;
}

/***
 * adds a process and expands the table if necessary
 */
void addProcessToTable(PROCESS process)
{
    if (processTableSize >= processTableCapacity) //if array too small
    {
        processTableCapacity *= 2; //double capacity
        processTable = (PROCESS *) realloc(processTable, processTableCapacity * sizeof(PROCESS));
    }
    processTable[processTableSize++] = process;

// TODO: complete

}

/***
 * display the processes table
 */
void displayProcessTable()
{
    printf("PROCESSES:\n\nName    \tEntry\tBurst\n");
    for (int i = 0; i < processTableSize; i++)
    {
        printf("%-8s\t%3d   \t%3d   \n", processTable[i].name, processTable[i].entryTime, processTable[i].burstTime);
    }
    printf("\n");
}

/***
 * determines if any processes in the process table still need to execute
 */
bool processesLeftToExecute()
{
// TODO: Implement
    int processTableIndex = 0;
    while (processTableIndex < processTableSize)
    {
        if(processTable[processTableIndex++].burstTime != 0)
        {
            return true;
        }
    }
    return false; //return 0 if all processes are complete
// TODO: Done
}

/***
 * adds any processes that arrive at the current time to ready queue
 */
void addArrivingProcessesToReadyQueue(int time)
{
// TODO: implement
for (int processIterIndex = 0; processIterIndex < processTableSize; ++processIterIndex)
{
    if(processTable[processIterIndex].entryTime == time)
    {
        addProcessToReadyQueue(&processTable[processIterIndex]);
    }
}
}

/***
 * adds a process to the ready queue and expands it if necessary
 */
void addProcessToReadyQueue(PROCESS *process)
{
// TODO: implement
    if(NULL == readyQueueHead)
    {
        //Empty Linked-List
        readyQueueHead = process;
        readyQueueTail = process;
    }
    else
    {
        //Add to new Process to Tail
        readyQueueTail->next = process;
        process->previous = readyQueueTail;
        readyQueueTail = process;
    }
}

/***
 * removes a process from the ready queue and fills the "hole"
 */
void removeProcessFromReadyQueue(PROCESS *process)
{
// TODO: implement
//If queue is empty, return NULL
    if(readyQueueHead == NULL)
    {
        return;
    }
    //Process is @ head node
    if(readyQueueHead == process)
    {
        readyQueueHead = process->next;
    }
    //Process is @ tail Node
    if(readyQueueTail == process)
    {
        readyQueueTail = process->previous;
    }
    //Check if process is not a tail node
    if(process->next != NULL)
    {
        process->next->previous = process->previous;
    }
    //Check if process is not a head node
    if(process->previous != NULL)
    {
        process->previous->next = process->next;
    }
    process->previous = NULL;
    process->next = NULL;
}

/***
 * fetches the first process from the ready queue
 */
PROCESS *fetchFirstProcessFromReadyQueue()
{
// TODO: implement

    PROCESS* processIter = readyQueueHead;
    removeProcessFromReadyQueue(processIter);
    return processIter;

}

/***
 * finds the shortest job in the ready queue
 */
PROCESS *findShortestProcessInReadyQueue()
{
// TODO: implement

    PROCESS* processIter = readyQueueHead;
    PROCESS* shortestProcess = readyQueueHead;
    while(processIter != NULL)
    {
        if(shortestProcess->burstTime > processIter->burstTime)
        {
            shortestProcess = processIter;
        }
        processIter = processIter->next;
    }
    return shortestProcess;
}

/***
 * displays the contents of the ready queue
 */
void displayQueue()
{
    printf("QUEUE: ");

    if (readyQueueHead == NULL)
        printf("<empty>");
    else
    {
        for (PROCESS *curr = readyQueueHead; curr != NULL; curr = curr->next)
        {
            printf("%s(%d) ", curr->name, curr->burstTime);
        }
    }
}

/***
 * calculates and prints the average wait time using information in the process table
 */
void printAverageWaitTime()
{
    int i = 0;
    double sum = 0;
    for (i = 0; i < processTableSize; i++)
    {
        sum = sum + processTable[i].waitTime;
        printf("Process %s Wait Time: %.2lf\n", processTable[i].name, (double) processTable[i].waitTime);
    }
    printf("Average Wait Time: %.2lf\n", (sum / (double) processTableSize));
}

/***
 * clean up the process table
 */
void cleanUp()
{
// TODO: implement
    free(processTable);
}





