//
// Created by seanblanchard on 9/22/20.
//

#ifndef LAB04_MESSAGE_H
#define LAB04_MESSAGE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>
#include <errno.h>
#include <stdbool.h>
#include <mqueue.h>

#define SERVER_NAME "/SERVER" // message queue name must start with '/'

#define MONITOR_QUEUE "/MONITOR"
#define NODE_NAME_PREFIX "NODE_"

#define MAX_MSG_SIZE 1024
#define TYPE 1

// Message attributes
typedef struct message {
    bool stable;
    int nodeId;
    float temperature;
} MESSAGE;

// Monitor Data Collection
typedef struct temperature {
    mqd_t msqid;
    float previousTemperature;
} TEMPERATURE;



#define oops(ermsg,erno) {perror(ermsg); exit(erno); }

#endif
