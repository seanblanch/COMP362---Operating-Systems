/**
* Name: Sean Blanchard
* Lab/task: Lab 4
* Date: 09/23/2020
**/

#include "message.h"


mqd_t openOutgoingMessageQueue() {
    mqd_t monitor;
    if ((monitor = mq_open(MONITOR_QUEUE,  O_WRONLY) == -1))
        oops("CLI: Error opening a queue.", errno);
    return monitor;
}

char *messageDescriptionForNode(char *const *argv) {
    char name[NAME_MAX] = "";
    sprintf(name, "/%s%ld", NODE_NAME_PREFIX,
            strtol(argv[1], NULL, 10)); // Stack smashing is possible

    return name;
}

int main(int argc, char *argv[]) {

    //mqd_t my_msqid, your_msqid;
    MESSAGE msg_rcvd, msg_send;

    //unsigned int type;

// Open Outgoing Message Queue
    mqd_t monitor = openOutgoingMessageQueue();

    // Configure Message Description for Node
    char *name = messageDescriptionForNode(argv);

    // Open Incoming Message Queue
    TEMPERATURE node;
    if ((node.msqid = mq_open(name,  O_RDWR | O_CREAT, S_IWUSR | S_IRUSR) == -1))
        oops("CLI: Error opening a client queue.", errno);

    // Retrieve Initial Temperature
    node.previousTemperature = strtof(argv[2], NULL);
    //copy to node
    msg_send.nodeId = node.msqid;

    // Regular Operation
    while (true)
    {
        msg_rcvd.temperature = node.previousTemperature;

        // Send Temperature to Monitor
        if ((mq_send(monitor, (const char*)&msg_send, sizeof(MESSAGE), 0)) == -1)
            oops("mq_send (node.c)", errno);

        // Retrieve New Temperature from Monitor
        if ((mq_receive(node.msqid, (char*)&msg_rcvd, sizeof(MESSAGE), 0) == -1))
            oops("mq_receive (node.c)", errno);

        if (msg_rcvd.stable == 1)
            break;

        // new_node_temp = (previous_node_temp * 3 + 2 * new_integrated_temp) / 5;
        node.previousTemperature = (node.previousTemperature * 3 + 2 * msg_rcvd.temperature) / 5;

        printf("NODE %s TEMPERATURE: %f\n", argv[1], node.previousTemperature);
    }

    printf("NODE %f TERMINATING...", node.previousTemperature);

//    // Close Incoming Message Queue
//    if (mq_close(node.msqid) == -1)
//        oops("mq_close", errno);

    // Unlink Incoming Message
    if (mq_unlink(name) == -1)
        oops("mq_unlink", errno);

    if (mq_unlink(MONITOR_QUEUE) == -1)
        oops("mq_unlink", errno);

    exit(EXIT_SUCCESS);

}
