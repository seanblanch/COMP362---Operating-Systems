/**
* Name: Sean Blanchard
* Lab/task: Lab 4
* Date: 02/23/2020
**/

// Invocation: "$ ./monitor 200 4 25 50 75 100"
// [program | initMonitorTemp | numOfNodes | nodeTemps...]


#include "message.h"


void closeMonitorQueue()
{
    //remove any message queues that could of remained
    if(mq_unlink(MONITOR_QUEUE) == 0)
        printf("SRV: Message queue %s removed.\n", MONITOR_QUEUE);
}

mqd_t openMonitorQueue(struct mq_attr *attr) {
    closeMonitorQueue();
    mqd_t monitor_queue;
    if ((monitor_queue= mq_open(MONITOR_QUEUE, O_RDONLY | O_CREAT, S_IWUSR | S_IRUSR, attr)) < 0)
        oops("mq_open: Error opening a server queue.", errno);

    printf("SRV: Opened queue %s.\n", MONITOR_QUEUE);
    return monitor_queue;
}

void openNodeQueue(struct mq_attr *attr, TEMPERATURE *nodeData, int nodeIndex, char *node_name) {
    if ((nodeData[nodeIndex].msqid = mq_open(node_name, O_RDWR | O_CREAT, S_IWUSR | S_IRUSR, attr)) == -1)
    {
        oops("SRV: unable to open node queue", errno);
    }
    printf("SRV: %s Queue Opened.", node_name);
}

void forkNodeProcess(char *const *argv, int nodeIndex, const char *node_name) {
    pid_t pid = fork();

    if (pid < 0)
        oops("Fork Failed", errno);

    if (pid == 0) {
        if(execlp("./node", "node", node_name, argv[nodeIndex + 3], NULL)){
            oops("SRV: Unable to start node process.", errno);
        }
    }
}

void closeNodeQueue(const char *node_name) {
    if(mq_unlink(node_name) == 0)
        printf("SRV: Message queue %s removed.\n", node_name);
}

void createNode(char *const *argv, struct mq_attr *attr, TEMPERATURE *nodeData, int nodeIndex) {
    char node_name[NAME_MAX];
    sprintf(node_name, "/%s%d", NODE_NAME_PREFIX, nodeIndex);

    closeNodeQueue(node_name);
    openNodeQueue(attr, nodeData, nodeIndex, node_name);
    forkNodeProcess(argv, nodeIndex, node_name);
}

void createNodes(char *const *argv, struct mq_attr *attr, int numberOfNodes, TEMPERATURE *nodeData) {
    for (int nodeIndex = 0; nodeIndex < numberOfNodes; nodeIndex++)
    {
        createNode(argv, attr, nodeData, nodeIndex);
    }
}

void stableFlag(MESSAGE *msg_send, int numberOfNodes, const TEMPERATURE *nodeData) {
    (*msg_send).stable = true;
    for(int k = 0; k < numberOfNodes; ++k)
    {
        (*msg_send).nodeId = nodeData[k].msqid;

        if ((mq_send(nodeData[k].msqid, (const char*) msg_send, sizeof(MESSAGE), 0)) == -1)
            oops("mq_send", errno);
    }
}

int main(int argc, char *argv[]) {
    //mqd_t my_msqid, your_msqid;
    MESSAGE msg_rcvd, msg_send;
    TEMPERATURE monitor;
    //unsigned int type;

    // Not enough arguments passed
    if (argc < 4) {
        printf("<Initial temp> <Number of nodes> <nodes 1 temperature> \n");
        exit(EXIT_FAILURE);
    }


    struct mq_attr attr;
    // Message Queue attributes
    attr.mq_maxmsg = 10;
    attr.mq_msgsize = MAX_MSG_SIZE;
    attr.mq_curmsgs = 0;
    attr.mq_flags = 0;//Incoming message queue

    int numberOfNodes = (int)strtol(argv[2], NULL, 10);
    monitor.msqid = openMonitorQueue(&attr);
    // Monitor Data
    monitor.previousTemperature = strtof(argv[1], NULL);
    //long numberOfNodes = strtol(argv[2], NULL, 10);
    TEMPERATURE nodeData[numberOfNodes]; // Node Data Collection Array of temperatures

    //Outgoing message queue

    createNodes(argv, &attr, numberOfNodes, nodeData);

    float sumOfNodeTemps;
    int numberOfStability= 0;

    while(true)
    {
        sumOfNodeTemps = 0;

        // Find Temperature report from every node
        for(int i = 0; i < numberOfNodes; ++i)
        {
            if (mq_receive(monitor.msqid, (char *)&msg_rcvd, sizeof(MESSAGE), 0) == -1)
            {
                oops("mq_receive", errno);
            }

            nodeData[i].msqid = msg_rcvd.nodeId;
            sumOfNodeTemps += msg_rcvd.temperature;
            nodeData[i].previousTemperature = msg_rcvd.temperature;

        }

        monitor.previousTemperature = (2 * monitor.previousTemperature + sumOfNodeTemps) / 6;
        printf("MONITOR TEMPERATURE: %f", monitor.previousTemperature);

        for (int j = 0; j < numberOfNodes; ++j)
        {
            msg_send.nodeId = nodeData[j].msqid;
            msg_send.temperature = monitor.previousTemperature;

            // Same number receives as sends
            if ((mq_send(nodeData[j].msqid, (const char *)&msg_send, sizeof(MESSAGE), 0)) == -1)
            {
                oops("mq_send", errno);
            }

            //Stability Check
            if(nodeData[j].previousTemperature == monitor.previousTemperature)
                numberOfStability++;
        }

        if (numberOfStability == numberOfNodes)
            break;
    }

    puts("STABLE TEMPERATURE DECTECTED. \nMONITOR TERMINATING... \n");

    // Send Stable Flag to Every Node
    stableFlag(&msg_rcvd, numberOfNodes, nodeData);

    //Remove persisted message queues
    if(mq_close(monitor.msqid) == -1)
        oops("mq_close", errno);

    if(mq_unlink(MONITOR_QUEUE) == -1)
        oops("mq_unlink", errno);

    return 0;
}
