#ifndef REPLACE_OPT_H
#define REPLACE_OPT_H

#include "replace.h"

int searchOPT(int);
void insertOPT(int);
int findVictimPageOPT();
void displayOPT();
void freePageTableOPT(void);

#endif //REPLACE_OPT_H
