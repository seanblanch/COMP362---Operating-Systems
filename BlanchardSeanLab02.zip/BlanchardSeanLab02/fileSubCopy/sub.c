//Sean Blanchard
//Lab 02
//9/9/2020


#include<stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <memory.h>

//global variables
char *from = NULL;
char *to = NULL;
char *inputFile = NULL;
char *outputFile = NULL;


/**
 * C program to copy contents of one file to another.
 */

void argumentFinder(int argc, char *argv[]);

void replace();



// This main functions counts the number of input by the user in the argc
// Then it returns the user input and loads it into the array argv[].



int main(int argc, char* argv[])
{
/*
*	argc - the number of arguments passed to the program, will always be >= 1
*	argv - an array of strings containing each argument in order, again will always have at least one string
*/


    //Test
    printf( "argc:     %d\n", argc );
    printf( "argv[1]:  %s\n", argv[1] );

    if ( argc == 2 )
    {
        printf( "No arguments were passed.\n" );
        printf("'sub -h' for help!\n");
    } else if (3 <= argc && argc <= 8)
    {
        printf( "Arguments:\n" );
        for (int i = 1; i < argc; i++ )
        {
            printf( "  argv[%d] = %s\n", i, argv[i] );
        }

        argumentFinder(argc, argv);
        replace();

    } else
    {
        printf("Incorrect format\n");
        printf("'sub -h' for help!\n");
    }

    return 0;
}

void replace() {

    int swapIndex;
    char currentCharacter;
    bool flag = true;
    size_t fromLength = strlen(from);

    //Check the current character in file
    while ((currentCharacter = getchar()) != EOF)
    {
        //loop through from to get index of how many variables
        for(swapIndex = 0; swapIndex < fromLength; swapIndex++)
        {
            //compare if the current character is equal to the current character in from.
            if(currentCharacter == from[swapIndex])
            {
                putchar(to[swapIndex]);
                flag = true;
            }
            else
            {
                flag = false;
            }
        }

        if(flag == false)
        {
            putchar(currentCharacter);
        }

    }\

}


void argumentFinder(int argc, char *argv[]) {

    for (int i = 1; i < argc; i++) {
        int characterIndex = 0;

        if (argc == 3)
        {
            //help menu
            printf("%s", "USAGE:\n"
                         "   sub [ -h | --fromChars -+toChars [-i inputFile] [-o outputFile] ]\n"
                         "\n"
                         "DESCRIPTION:\n"
                         "   This utility copies text from an input stream to an output stream replacing every \n"
                         "   instance of a specific character in fromChars with a corresponding (position-wise) \n"
                         "   character from toChars. Any characters in fromChars and in toChars that do not \n"
                         "   have corresponding counterparts in the other one are ignored. If an input file is \n"
                         "   provided, the content is read from that file; otherwise, the standard input is used. \n"
                         "   If an output file is provided, then the modified content is written to that file; \n"
                         "   otherwise, the standard output is used.\n"
                         "\n"
                         "OPTIONS:\n"
                         "   --(followed by a string without separating space)\n"
                         "     indicates all characters that will be replaced in the processed text\n"
                         "   -+(followed by a string without separating space) \n"
                         "     indicates the characters that will be used to replace corresponding \n"
                         "     (position-wise) characters from fromChars in the processed text\n"
                         "   -i (followed by input file name) \n"
                         "     use the provided file as an input stream instead of standard input \n"
                         "   -o (followed by output file name) \n"
                         "     use the provided file as an output stream instead of standard output \n"
                         "   -h prints this help message; it is also a default if no command line\n"
                         "     arguments are provided");
        } else if (argc >= 4 && argc <= 8) {
            if (argv[i][characterIndex] == '-') {
                switch (argv[i][characterIndex + 1]) {
                    case 'h':
                        //help menu
                        exit(2);
                    case '-':
                        from = &(argv[i][(characterIndex + 2)]);
                        break;
                    case '+':
                        to = &(argv[i][(characterIndex + 2)]);
                        break;
                    case 'i':
                        i++;
                        if (i < argc) {
                            inputFile = &(argv[i][0]);
                            //getFile(inputFile, "r", stdin);
                            freopen(inputFile, "r", stdin);
                        } else {
                            exit(3); // must include input file after -i
                        }
                        break;
                    case 'o':
                        i++;
                        if (i < argc) {
                            outputFile = &(argv[i][0]);
                            //getFile(outputFile, "w", stdout);
                            freopen(outputFile, "w", stdout);
                        } else {
                            exit(4); // must include output file after -o
                        }
                        break;
                    default:
                        break;
                }
            }
        }
    }

    //Test Arguments
//    printf("This is from: %s\n", from);
//    printf("This is to: %s\n", to);
//    printf("This is inputFile: %s\n", inputFile);
//    printf("This is outputFile: %s\n", outputFile);
}

